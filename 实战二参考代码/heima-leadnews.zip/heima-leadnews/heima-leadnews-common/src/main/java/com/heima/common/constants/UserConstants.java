package com.heima.common.constants;

public class UserConstants {
    public static final Short PASS_AUTH = 9;
    public static final Short FAIL_AUTH = 2;
    public static final Integer AUTH_TYPE = 2;
}