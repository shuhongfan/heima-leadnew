package com.heima.model.comment.vos;

import lombok.Data;

@Data
public class CountVo {

    private Long countNum;
}
